const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json")
const db = require("nrc.db")
const {MessageActionRow, MessageButton} = require("discord.js")
module.exports = {
    calistir: async(client, message, args) => {

    if(message.author.id !== message.guild.ownerId) return message.reply(`Bu komudu kullanmak için yetkin yok`)
		const menu = new Discord.MessageEmbed()
		.setColor("RANDOM")
		.setTitle("FK Ailesi Başuru Sistemi")
	    .setImage("https://cdn.discordapp.com/attachments/965659997386203136/971407602451906570/FK.png")
		.setDescription(`
		Aile Başvurusu İçin Aşağıdaki Butona Basınız.`)

		const row = new MessageActionRow()
		.addComponents(
		new MessageButton()
		.setCustomId('bot-başvuru')
		.setLabel('Başvuru İçin Tıkla')
		.setEmoji("📄")
		.setStyle('SECONDARY'),
		
		);
		message.channel.send({
			embeds: [menu], components: [row]
		});


},

name: "kayıt",
description: "",
aliases: [],
kategori: "",
usage: "",
}