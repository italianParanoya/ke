const { Client, Intents, Collection, MessageAttachment, MessageEmbed, Permissions, Constants, ApplicationCommandPermissionsManager, MessageButton, MessageActionRow } = require('discord.js');
const Discord = require("discord.js")
const client = new Client({ intents: [Intents.FLAGS.GUILDS,Intents.FLAGS.GUILD_MEMBERS,Intents.FLAGS.GUILD_BANS,Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,Intents.FLAGS.GUILD_INTEGRATIONS,Intents.FLAGS.GUILD_WEBHOOKS,Intents.FLAGS.GUILD_INVITES,Intents.FLAGS.GUILD_VOICE_STATES,Intents.FLAGS.GUILD_MESSAGES,Intents.FLAGS.GUILD_MESSAGE_REACTIONS,Intents.FLAGS.GUILD_MESSAGE_TYPING,Intents.FLAGS.DIRECT_MESSAGES,Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,Intents.FLAGS.DIRECT_MESSAGE_TYPING] });
const ayarlar = require("./ayarlar.json");
const db = require("nrc.db");
const message = require("./events/message");
require('dotenv').config();
let prefix = ayarlar.prefix;
client.commands = new Collection();
client.aliases = new Collection();

["command"].forEach(handler => {
  require(`./komutcalistirici`)(client);
}); 

client.on("ready", () => {
  require("./events/eventLoader")(client);
});





const { Modal, TextInputComponent, showModal } = require('discord-modals') 
const discordModals = require('discord-modals') 
discordModals(client); 



client.on('messageCreate', (message) => {
	if(message.content === 'botlist') {
		const menu = new Discord.MessageEmbed()
		.setColor("RANDOM")
		.setTitle("FK Ailesi Başuru Sistemi")
		.setDescription(`
		Aile Başvurusu İçin Aşağıdaki Butona Basınız.`)

		const row = new MessageActionRow()
		.addComponents(
		new MessageButton()
		.setCustomId('bot-başvuru')
		.setLabel('Başvuru İçin Tıkla')
		.setEmoji("🤖")
		.setStyle('SECONDARY'),
		
		);
		message.channel.send({
			embeds: [menu], components: [row]
		});
	}
});

const nrcmodal = new Modal() 
.setCustomId('narcos-botlist')
.setTitle('Aile Başvuru Formu')
.addComponents(
  new TextInputComponent() 
  .setCustomId('bot-id')
  .setLabel('Adınız?')
  .setStyle('SHORT') 
  .setMinLength(3)
  .setMaxLength(20)
  .setPlaceholder('Örnek : Burak')
  .setRequired(true)
)
.addComponents(
	new TextInputComponent() 
	.setCustomId('bot-prefix')
	.setLabel('Yaşınız?')
	.setStyle('SHORT') 
	.setMaxLength(2)
	.setPlaceholder('Örnek: 18')
	.setRequired(true)
  )
  .addComponents(
	new TextInputComponent() 
	.setCustomId('bot-onay')
	.setLabel('Ne olmak istiyorsunuz?')
	.setStyle('SHORT') 
	.setMinLength(5)
	.setMaxLength(7)
	.setPlaceholder('Mekanik / Torbacı / Emlak')
	.setRequired(true)
  )
  .addComponents(
	new TextInputComponent() 
	.setCustomId('bot-hakkinda')
	.setLabel('Kendinizi Tanıtınız')
	.setMaxLength(500)
	.setStyle('LONG') 
	.setRequired(true)
	.setMinLength(1)
	.setPlaceholder('Daha hızlı onay almak için kendinizi detaylı tanıtınız.')
  )


client.on('interactionCreate', async (interaction) => {

	if(interaction.customId === "bot-başvuru"){
		showModal(nrcmodal, {
			client: client, 
			interaction: interaction 
		  })
	}
	if(interaction.customId === "botred"){
		if(!interaction.member.roles.cache.has(ayarlar.botlistyetkilirol)) {
            return  interaction.reply({content: "Bu Komutu Kullanabilmek İçin Gerekli Yetkiye Sahip Değilsin!..", ephemeral: true});
     }
		const redform = new Modal() 
.setCustomId('narcos-botlist-red')
.setTitle('Başvuru Red Sebep Formu')
  .addComponents(
	new TextInputComponent() 
	.setCustomId('red-sebep')
	.setLabel('Reddetme Sebebinizi Belirtiniz.')
	.setStyle('LONG') 
	.setMinLength(1)
	.setMaxLength(500)
	.setPlaceholder('Yetersiz bilgilendirme \nYaş Yetersizliği \nMeslek doluluğu')
	.setRequired(true)
  )
		showModal(redform, {
			client: client, 
			interaction: interaction 
		  })

		}




	if(interaction.customId === "botonay"){

		
        if(!interaction.member.roles.cache.has(ayarlar.botlistyetkilirol)) {
            return  interaction.reply({content: "Bu Komutu Kullanabilmek İçin Gerekli Yetkiye Sahip Değilsin!..", ephemeral: true});
     }

		let sahip = db.fetch(`onay-red-mesaj_${interaction.message.id}`)
		let botid = db.fetch(`bot_id_${sahip}`)

		const embed = new Discord.MessageEmbed()
		.setColor("RANDOM")
			.setDescription(`
		**${botid}** Kişisini Başvurusu Onaylandı.
		**Onaylayan Yetkili:** <@${interaction.user.id}> (${interaction.user.id})
		`)
		const row = new MessageActionRow()
		.addComponents(
		new MessageButton()
		.setCustomId('onaylandı')
		.setLabel('Başvuru Onaylandı')
		.setStyle('SUCCESS')
		.setDisabled(true)
		
		);
		await interaction.update({ embeds: [embed] , components: [row] });
		db.delete(`onay-red-mesaj_${interaction.message.id}`)
		db.delete(`bot_bilgi_${botid}`)
		db.delete(`bot_${botid}`)
		const embedd = new Discord.MessageEmbed()
		.setColor("GREEN")
		.setImage("https://cdn.discordapp.com/attachments/965659997386203136/971417265331400794/onay.png")
		.setDescription(`
		<@${sahip}> isimli kullanıcının başvurusu <@${interaction.user.id}> tarafından onaylandı.
		`)
		
		client.channels.cache.get(ayarlar['onay-red-log']).send({embeds:[embedd]})

	}

});


client.on('modalSubmit',async (modal) => {

	if(modal.customId === 'narcos-botlist-red'){

		let sahip = db.fetch(`onay-red-mesaj_${modal.message.id}`)
		const aciklama = modal.getTextInputValue('red-sebep')
		
		const embed = new Discord.MessageEmbed()
		.setColor("RED")
		.setImage("https://cdn.discordapp.com/attachments/965659997386203136/971417265608204348/red.png")
		.setDescription(`
		<@${sahip}> isimli kullanıcının başvurusu <@${modal.user.id}> tarafından reddedildi.
		> **Sebep :** ${aciklama}
		`)
		await modal.deferReply({ ephemeral: true })
 		modal.followUp({ content: `Başarılı Bir Şekilde Reddedildi.`, ephemeral: true })
		client.channels.cache.get(ayarlar['onay-red-log']).send({embeds:[embed]})

		let botid = db.fetch(`bot_id_${sahip}`)
		db.delete(`bot_id_${sahip}`)
		db.delete(`onay-red-mesaj_${modal.message.id}`)
		db.delete(`bot_bilgi_${botid}`)
		db.delete(`bot_${botid}`)

		const embedd = new Discord.MessageEmbed()
		.setColor("RED")
			.setDescription(`
		**${botid}** Kişisinin Başvurusu Reddedildi.
		**Reddeden Kişi :** <@${modal.user.id}> 
		> **Sebep :** ${aciklama}
		`)
		const row = new MessageActionRow()
		.addComponents(
		new MessageButton()
		.setCustomId('reddedildi')
		.setLabel('Başvuru Reddedildi')
		.setStyle('DANGER')
		.setDisabled(true)
		
		);
		client.channels.cache.get(ayarlar.botlog).messages.edit(modal.message.id, {embeds: [embedd], components: [row]})
	}

	if(modal.customId === 'narcos-botlist'){
		const botid = modal.getTextInputValue('bot-id')
		const botprefix = modal.getTextInputValue('bot-prefix')
		const topgg = modal.getTextInputValue('bot-onay')
		const aciklama = modal.getTextInputValue('bot-hakkinda')
		let kontrol = db.fetch(`bot_id_${modal.user.id}`)
		await modal.deferReply({ ephemeral: true })
		if(kontrol) return  modal.followUp({ content: `Zaten Başvuru Yapmışsınız Onaylanmasını Bekleyiniz.`, ephemeral: true })
		let kontrol2 = db.fetch(`bot_${botid}`)
		if(kontrol2) return  modal.followUp({ content: `Bu Başvuru Zaten Sistemimizde Var.`, ephemeral: true })
		db.set(`bot_id_${modal.user.id}`, botid)
		db.set(`bot_${botid}`, modal.user.id)
		db.set(`bot_bilgi_${botid}`, [])
		db.push(`bot_bilgi_${botid}`, botprefix)
		db.push(`bot_bilgi_${botid}`, topgg)
		db.push(`bot_bilgi_${botid}`, aciklama ? aciklama : "açıklama bulunamadı")
		modal.followUp({ content: `Başarılı Bir Şekilde Başvurunuz İletildi.`, ephemeral: true })

		const row = new MessageActionRow()
		.addComponents(
		new MessageButton()
		.setCustomId('botonay')
		.setLabel('Başvuruyu Onayla')
		.setStyle('SUCCESS'),
		
		new MessageButton()
		.setCustomId('botred')
		.setLabel('Başvuruyu Reddet')
		.setStyle('DANGER'),
		);

		const embed = new Discord.MessageEmbed()
		.setColor("RANDOM")
		.setDescription(`
		> **Yeni Başvuru !**

		**Adı :** \`\`\`\ ${botid}\`\`\`\
		**Yaşı :** \`\`\`\ ${botprefix}\`\`\`\
		**Ne olmak istiyor :** \`\`\`\ ${topgg} \`\`\`\
		**Hakkında :**
		\`\`\`\ ${aciklama ? aciklama: "Açıklama Bulunamadı."} \`\`\`\

		> **Kullanıcı Bilgileri;**

		**İD:** \`${modal.user.id} ${modal.user.username}\`
		**Etiket:** <@${modal.user.id}>
		`)
		.setImage("https://cdn.discordapp.com/attachments/965659997386203136/971415027540189245/cyprus.gif")
		client.channels.cache.get(ayarlar.botlog).send({embeds:[embed],components: [row]}).then(c => {
			db.set(`onay-red-mesaj_${c.id}`, modal.user.id)
		})
		
	  
	}  
  })



  client.on('guildMemberRemove',async (member) => {

	let kontrol = db.fetch(`bot_id_${member.id}`)

	if(!kontrol) return

	let user = member.guild.members.cache.get(kontrol)
	console.log(user)
	user.ban({reason: "Sahibi Sunucudan Çıktı"})
	const embed = new Discord.MessageEmbed()
	.setColor("RANDOM")
	.setDescription(`${member}, sunucudan çıktı botunuda sunucudan banladım`)
	client.channels.cache.get(ayarlar['cikti-log']).send({embeds:[embed]})

  })

client.login(ayarlar.token);
